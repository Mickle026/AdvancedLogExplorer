define(["require", "jQuery", "globalize", "emby-button", "emby-select", "emby-input", "emby-checkbox"],
function (require, $, globalize) {

    var view = null;

    var lastResult = "";        // raw log text returned by server (for current filter)
    var filteredResult = "";    // filtered log (same as lastResult from server)
    var autoRefreshTimer = null;
    var paused = false;

    // Live search state
    var searchMatches = [];
    var currentMatchIndex = -1;

    // ---------- Helpers: coloring & highlighting ----------
    function colorizeLine(line) {
        if (/error|exception/i.test(line)) return "<span style='color:#ff5555;'>" + line + "</span>";
        if (/warn/i.test(line))           return "<span style='color:#ffb86c;'>" + line + "</span>";
        if (/info/i.test(line))           return "<span style='color:#8be9fd;'>" + line + "</span>";
        if (/debug/i.test(line))          return "<span style='color:#50fa7b;'>" + line + "</span>";
        return line;
    }

    function highlightSearch(text, search, lineIndex) {
        if (!search) return text;

        var caseSensitive = $("#caseSensitiveToggle", view).prop("checked");
        var regexMode     = $("#regexToggle", view).prop("checked");
        var flags = caseSensitive ? "g" : "gi";

        var regex;
        try {
            regex = regexMode ? new RegExp(search, flags) :
                new RegExp("(" + search.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + ")", flags);
        } catch (e) {
            // Invalid regex → fallback to literal
            regex = new RegExp("(" + search.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + ")", flags);
        }

        var hasMatch = false;
        var replaced = text.replace(regex, function (m) {
            hasMatch = true;
            return "<span class='searchMatch' data-line='" + lineIndex + "' style='background:yellow;color:black;'>" + m + "</span>";
        });
        if (hasMatch) searchMatches.push(lineIndex);
        return replaced;
    }

    // ---------- Rendering ----------
    function renderOutput(text) {
        var html = "";
        var lines = text ? text.split(/\r?\n/) : [];
        var search = $("#liveSearch", view).val();

        searchMatches = [];
        currentMatchIndex = -1;

        for (var i = 0; i < lines.length; i++) {
            if (lines[i] === "") continue; // skip blanks
            var colored = colorizeLine(lines[i]);
            colored = highlightSearch(colored, search, i);
            html += "<div id='line-" + i + "'><span style='color:#888;'>" +
                (i + 1).toString().padStart(5, " ") + " </span>" + colored + "</div>";
        }

        $("#logOutput", view).html(html);

        if (search) {
            $("#searchCount", view).text(searchMatches.length + " matches");
            if (searchMatches.length > 0) scrollToMatch(0); // auto-jump to first
        } else {
            $("#searchCount", view).text("");
        }

        if ($("#autoScrollToggle", view).prop("checked") && !search) {
            var output = $("#logOutput", view).get(0);
            if (output) output.scrollTop = output.scrollHeight;
        }
    }

    function renderRaw(text) {
        var html = "";
        var lines = text ? text.split(/\r?\n/) : [];
        var search = $("#liveSearch", view).val();

        for (var i = 0; i < lines.length; i++) {
            if (lines[i] === "") continue;
            var colored = colorizeLine(lines[i]);
            colored = highlightSearch(colored, search, i);
            html += "<div id='raw-line-" + i + "'><span style='color:#666;'>" +
                (i + 1).toString().padStart(5, " ") + " </span>" + colored + "</div>";
        }

        $("#rawLogOutput", view).html(html);

        if ($("#autoScrollToggle", view).prop("checked") && !search) {
            var output = $("#rawLogOutput", view).get(0);
            if (output) output.scrollTop = output.scrollHeight;
        }
    }

    function scrollToMatch(index) {
        if (index < 0 || index >= searchMatches.length) return;
        currentMatchIndex = index;
        var lineNum = searchMatches[currentMatchIndex];

        // Filtered
        var $line = $("#line-" + lineNum, view);
        if ($line.length) {
            $("#logOutput div", view).removeClass("activeMatchLine");
            $line[0].scrollIntoView({ behavior: "smooth", block: "center" });
            $line.addClass("activeMatchLine");
            $(".searchMatch", view).css("outline", "none");
            $line.find(".searchMatch").css("outline", "2px solid orange");
        }

        // Raw (if visible)
        if ($("#splitViewToggle", view).prop("checked")) {
            var $raw = $("#raw-line-" + lineNum, view);
            if ($raw.length) {
                $("#rawLogOutput div", view).removeClass("activeMatchLine");
                $raw[0].scrollIntoView({ behavior: "smooth", block: "center" });
                $raw.addClass("activeMatchLine");
                $raw.find(".searchMatch").css("outline", "2px solid orange");
            }
        }
    }

    // ---------- Server calls ----------
    function loadPluginFilters(file) {
        $("#pluginFilter", view).empty().append($("<option>").val("").text(""));
        if (!file) return;

        ApiClient.getJSON(ApiClient.getUrl("AdvancedLogExplorer/GetPluginFilters", { File: file }))
            .then(function (plugins) {
                var sel = $("#pluginFilter", view).empty();
                sel.append($("<option>").val("").text(""));
                (plugins || []).forEach(function (p) {
                    sel.append($("<option>").val("plugin:" + p).text(p));
                });
            }).catch(function (e) {
                console.warn("GetPluginFilters failed", e);
            });
    }

    function applyFilter() {
        var file    = $("#logFileSelect", view).val();
        var k1      = $("#keyword1", view).val();
        var k2      = $("#keyword2", view).val();
        var op      = $("#operator", view).val();
        var preset  = $("#preset", view).val();
        var plugin  = $("#pluginFilter", view).val();
        var lines   = parseInt($("#lineLimit", view).val(), 10) || 0;

        if (plugin) preset = plugin;

        ApiClient.getJSON(ApiClient.getUrl("AdvancedLogExplorer/GetLogContent", {
            File: file,
            Keyword1: k1,
            Keyword2: k2,
            Operator: op,
            Preset: preset,
            Lines: lines
        })).then(function (resp) {
            var text = (resp && resp.Content) ? resp.Content : "";
            lastResult = text;
            filteredResult = text;

            renderOutput(filteredResult);

            if ($("#splitViewToggle", view).prop("checked")) {
                $("#rawLogContainer", view).addClass("open");
                renderRaw(lastResult);
            } else {
                $("#rawLogContainer", view).removeClass("open");
            }
        }).catch(function (e) {
            console.error("GetLogContent failed", e);
        });
    }

    function checkLogRotation() {
        var currentFile = $("#logFileSelect", view).val();
        if (!currentFile) return;

        var base = currentFile.replace(/-\d+\.txt$/, ".txt");
        var prefix = base.replace(/\.txt$/, "");

        ApiClient.getJSON(ApiClient.getUrl("AdvancedLogExplorer/GetLogs"))
            .then(function (files) {
                if (!files || files.length === 0) return;
                var newest = files.find(function (f) { return f.indexOf(prefix) === 0; });
                if (newest && newest !== currentFile) {
                    $("#logFileSelect", view).val(newest);
                    loadPluginFilters(newest);
                    applyFilter();
                }
            }).catch(function (e) {
                console.warn("GetLogs (rotation) failed", e);
            });
    }

    function startAutoRefresh() {
        stopAutoRefresh();
        var interval = parseInt($("#autoRefreshInterval", view).val(), 10) || 5000;
        autoRefreshTimer = setInterval(function () {
            if (paused) return;
            if ($("#rotationToggle", view).prop("checked")) checkLogRotation();
            applyFilter();
        }, interval);
    }

    function stopAutoRefresh() {
        if (autoRefreshTimer) clearInterval(autoRefreshTimer);
        autoRefreshTimer = null;
    }

    function loadLogs() {
        ApiClient.getJSON(ApiClient.getUrl("AdvancedLogExplorer/GetLogs")).then(function (files) {
            var sel = $("#logFileSelect", view).empty();
            (files || []).forEach(function (f) {
                sel.append($("<option>").attr("value", f).text(f));
            });

            var defaultFile = "embyserver.txt";
            if (files && files.includes(defaultFile)) sel.val(defaultFile);
            else if (files && files.length > 0) sel.val(files[0]);

            var file = sel.val();
            loadPluginFilters(file);
            applyFilter();
        }).catch(function (e) {
            console.error("GetLogs failed", e);
        });
    }

    // ---------- Export / Copy / Download ----------
    function copyFiltered() {
        var text = filteredResult || "";
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).catch(function () {
                fallbackCopy(text);
            });
        } else {
            fallbackCopy(text);
        }
    }

    function fallbackCopy(text) {
        var ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "fixed";
        ta.style.left = "-1000px";
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand("copy"); } catch (e) { console.warn("copy failed", e); }
        document.body.removeChild(ta);
    }

    function downloadFiltered() {
        var blob = new Blob([filteredResult || ""], { type: "text/plain" });
        var url = URL.createObjectURL(blob);
        var a = document.createElement("a");
        var file = $("#logFileSelect", view).val() || "log";
        a.href = url;
        a.download = "Filtered_" + file;
        a.click();
        URL.revokeObjectURL(url);
    }

    function exportSession() {
        var file       = $("#logFileSelect", view).val();
        var includeRaw = $("#includeRawToggle", view).prop("checked");
        var compress   = $("#compressRawToggle", view).prop("checked");
        var k1         = $("#keyword1", view).val();
        var k2         = $("#keyword2", view).val();
        var op         = $("#operator", view).val();
        var preset     = $("#preset", view).val();
        var plugin     = $("#pluginFilter", view).val();
        var lines      = parseInt($("#lineLimit", view).val(), 10) || 0;
        var auto       = $("#autoRefreshToggle", view).prop("checked");

        if (plugin) preset = plugin;

        ApiClient.ajax({
            type: "POST",
            url: ApiClient.getUrl("AdvancedLogExplorer/ExportSession"),
            data: JSON.stringify({
                FileName: file,
                FilteredLog: filteredResult || "",
                RawLog: lastResult || "",
                Keyword1: k1 || "",
                Keyword2: k2 || "",
                Operator: op || "NONE",
                Preset: preset || "",
                LineLimit: lines,
                AutoRefresh: auto,
                IncludeRaw: includeRaw,
                CompressRaw: compress
            }),
            contentType: "application/json",
            dataType: "arraybuffer"
        }).then(function (zipData) {
            var blob = new Blob([zipData], { type: "application/zip" });
            var url = URL.createObjectURL(blob);
            var a = document.createElement("a");
            a.href = url;
            a.download = "AdvancedLogExplorer_Session.zip";
            a.click();
            URL.revokeObjectURL(url);
        }).catch(function (e) { console.error("ExportSession failed", e); });
    }

    // ---------- Quick settings button inside the log header ----------
    function injectQuickSettingsButton() {
        var h3 = $("#logOutput", view).prev("h3");
        if (h3.length && $("#quickSettingsBtn", view).length === 0) {
            h3.css({ display: "flex", alignItems: "center" });
            var spacer = $("<span>").css({ flex: "1" });
            var btn = $("<button id='quickSettingsBtn' is='emby-button' class='raised' title='Settings'>⚙</button>");
            h3.append(spacer).append(btn);
            $(view).on("click", "#quickSettingsBtn", function () {
                $("#settingsModal", view).show();
            });
        }
    }

    // ---------- Controller ----------
    return function (page) {
        view = page;

        page.addEventListener("viewshow", function () {
            loadLogs();
            injectQuickSettingsButton();

            // Auto-focus search
            setTimeout(function () { $("#liveSearch", view).focus(); }, 300);

            // File + filters changes
            $(view).on("change", "#logFileSelect", function () {
                loadPluginFilters(this.value);
                applyFilter();
            });
            $(view).on("change", "#preset,#pluginFilter,#operator,#lineLimit", applyFilter);

            // Apply / Refresh (auto-close modal)
            $(view).on("click", "#applyFilter", function () {
                applyFilter();
                $("#settingsModal", view).hide();
            });
            $(view).on("click", "#refreshBtn", function () {
                applyFilter();
                $("#settingsModal", view).hide();
            });

            // Settings modal open/close
            $(view).on("click", "#settingsBtn", function () {
                $("#settingsModal", view).show();
            });
            $(view).on("click", "#closeSettings", function () {
                $("#settingsModal", view).hide();
            });
            $(view).on("click", "#settingsModal", function (e) {
                if (e.target.id === "settingsModal") $(this).hide();
            });

            // Auto refresh
            $(view).on("change", "#autoRefreshToggle", function () {
                if (this.checked) startAutoRefresh();
                else stopAutoRefresh();
            });
            $(view).on("change", "#autoRefreshInterval", function () {
                if ($("#autoRefreshToggle", view).prop("checked")) startAutoRefresh();
            });

            // Split view toggle (CSS class)
            $(view).on("change", "#splitViewToggle", function () {
                if (this.checked) {
                    $("#rawLogContainer", view).addClass("open");
                    renderRaw(lastResult);
                    if (searchMatches.length > 0) {
                        scrollToMatch(currentMatchIndex >= 0 ? currentMatchIndex : 0);
                    }
                } else {
                    $("#rawLogContainer", view).removeClass("open");
                }
            });

            // Live search + toggles
            $(view).on("input", "#liveSearch", function () {
                renderOutput(lastResult);
                if ($("#splitViewToggle", view).prop("checked")) renderRaw(lastResult);
            });
            $(view).on("change", "#caseSensitiveToggle,#regexToggle", function () {
                renderOutput(lastResult);
                if ($("#splitViewToggle", view).prop("checked")) renderRaw(lastResult);
            });

            // Search navigation + clear
            $(view).on("click", "#nextMatchBtn", function () {
                if (searchMatches.length > 0) scrollToMatch((currentMatchIndex + 1) % searchMatches.length);
            });
            $(view).on("click", "#prevMatchBtn", function () {
                if (searchMatches.length > 0) scrollToMatch((currentMatchIndex - 1 + searchMatches.length) % searchMatches.length);
            });
            $(view).on("click", "#clearSearchBtn", function () {
                $("#liveSearch", view).val("");
                $("#searchCount", view).text("");
                searchMatches = [];
                currentMatchIndex = -1;
                renderOutput(lastResult);
                if ($("#splitViewToggle", view).prop("checked")) renderRaw(lastResult);
                $("#liveSearch", view).focus();
            });

            // Keyboard shortcuts
            $(view).on("keydown", "#liveSearch", function (e) {
                if (e.key === "Enter") {
                    e.preventDefault();
                    if (searchMatches.length === 0) return;
                    if (e.shiftKey) scrollToMatch((currentMatchIndex - 1 + searchMatches.length) % searchMatches.length);
                    else            scrollToMatch((currentMatchIndex + 1) % searchMatches.length);
                } else if (e.key === "Escape") {
                    e.preventDefault();
                    $("#clearSearchBtn", view).click();
                }
            });
            $(document).on("keydown.ale", function (e) {
                if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "f") {
                    e.preventDefault();
                    $("#liveSearch", view).focus().select();
                }
            });

            // Export / Copy / Download
            $(view).on("click", "#copyBtn", copyFiltered);
            $(view).on("click", "#downloadBtn", downloadFiltered);
            $(view).on("click", "#exportSessionBtn", exportSession);
        });

        page.addEventListener("viewhide", function () {
            stopAutoRefresh();
            $(document).off("keydown.ale");
        });
    };
});
