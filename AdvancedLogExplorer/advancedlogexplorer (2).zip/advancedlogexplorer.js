define(["require", "jQuery", "globalize", "emby-button", "emby-select", "emby-input", "emby-checkbox"],
function (require, $, globalize) {

    var view = null;
    var lastResult = "";
    var filteredResult = "";
    var autoRefreshTimer = null;
    var paused = false;
    var searchMatches = [];
    var currentMatchIndex = -1;

    function colorizeLine(line) {
        if (/error|exception/i.test(line)) return "<span style='color:#ff5555;'>" + line + "</span>";
        if (/warn/i.test(line))           return "<span style='color:#ffb86c;'>" + line + "</span>";
        if (/info/i.test(line))           return "<span style='color:#8be9fd;'>" + line + "</span>";
        if (/debug/i.test(line))          return "<span style='color:#50fa7b;'>" + line + "</span>";
        return line;
    }

    function highlightSearch(text, search, lineIndex) {
        if (!search) return text;
        var caseSensitive = $("#caseSensitiveToggle", view).prop("checked");
        var regexMode     = $("#regexToggle", view).prop("checked");
        var flags = caseSensitive ? "g" : "gi";
        var regex;
        try {
            regex = regexMode ? new RegExp(search, flags) :
                new RegExp("(" + search.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + ")", flags);
        } catch (e) {
            regex = new RegExp("(" + search.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + ")", flags);
        }
        var hasMatch = false;
        var replaced = text.replace(regex, function (m) {
            hasMatch = true;
            return "<span class='searchMatch' data-line='" + lineIndex + "' style='background:yellow;color:black;'>" + m + "</span>";
        });
        if (hasMatch) searchMatches.push(lineIndex);
        return replaced;
    }

    function renderOutput(text) {
        var html = "";
        var lines = text ? text.split(/\\r?\\n/) : [];
        var search = $("#liveSearch", view).val();
        searchMatches = [];
        currentMatchIndex = -1;
        for (var i = 0; i < lines.length; i++) {
            if (!lines[i]) continue;
            var colored = colorizeLine(lines[i]);
            colored = highlightSearch(colored, search, i);
            html += "<div id='line-" + i + "'><span style='color:#888;'>" +
                (i + 1).toString().padStart(5, " ") + " </span>" + colored + "</div>";
        }
        $("#logOutput", view).html(html);
        if (search) {
            $("#searchCount", view).text(searchMatches.length + " matches");
            if (searchMatches.length > 0) scrollToMatch(0);
        } else $("#searchCount", view).text("");
        if ($("#autoScrollToggle", view).prop("checked") && !search) {
            var output = $("#logOutput", view).get(0);
            output.scrollTop = output.scrollHeight;
        }
    }

    function renderRaw(text) {
        var html = "";
        var lines = text ? text.split(/\\r?\\n/) : [];
        var search = $("#liveSearch", view).val();
        for (var i = 0; i < lines.length; i++) {
            if (!lines[i]) continue;
            var colored = colorizeLine(lines[i]);
            colored = highlightSearch(colored, search, i);
            html += "<div id='raw-line-" + i + "'><span style='color:#666;'>" +
                (i + 1).toString().padStart(5, " ") + " </span>" + colored + "</div>";
        }
        $("#rawLogOutput", view).html(html);
        if ($("#autoScrollToggle", view).prop("checked") && !search) {
            var output = $("#rawLogOutput", view).get(0);
            output.scrollTop = output.scrollHeight;
        }
    }

    function scrollToMatch(index) {
        if (index < 0 || index >= searchMatches.length) return;
        currentMatchIndex = index;
        var lineNum = searchMatches[currentMatchIndex];
        var $line = $("#line-" + lineNum, view);
        if ($line.length) {
            $("#logOutput div", view).removeClass("activeMatchLine");
            $line[0].scrollIntoView({ behavior: "smooth", block: "center" });
            $line.addClass("activeMatchLine");
            $(".searchMatch", view).css("outline", "none");
            $line.find(".searchMatch").css("outline", "2px solid orange");
        }
        if ($("#splitViewToggle", view).prop("checked")) {
            var $raw = $("#raw-line-" + lineNum, view);
            if ($raw.length) {
                $("#rawLogOutput div", view).removeClass("activeMatchLine");
                $raw[0].scrollIntoView({ behavior: "smooth", block: "center" });
                $raw.addClass("activeMatchLine");
                $raw.find(".searchMatch").css("outline", "2px solid orange");
            }
        }
    }

    function loadPluginFilters(file) {
        $("#pluginFilter", view).empty().append($("<option>").val("").text(""));
        if (!file) return;
        ApiClient.getJSON(ApiClient.getUrl("AdvancedLogExplorer/GetPluginFilters", { File: file }))
            .then(function (plugins) {
                var sel = $("#pluginFilter", view).empty();
                sel.append($("<option>").val("").text(""));
                (plugins || []).forEach(function (p) {
                    sel.append($("<option>").val("plugin:" + p).text(p));
                });
            });
    }

    function applyFilter() {
        var file    = $("#logFileSelect", view).val();
        var k1      = $("#keyword1", view).val();
        var k2      = $("#keyword2", view).val();
        var op      = $("#operator", view).val();
        var preset  = $("#preset", view).val();
        var plugin  = $("#pluginFilter", view).val();
        var lines   = parseInt($("#lineLimit", view).val(), 10) || 0;
        if (plugin) preset = plugin;
        ApiClient.getJSON(ApiClient.getUrl("AdvancedLogExplorer/GetLogContent", {
            File: file, Keyword1: k1, Keyword2: k2, Operator: op, Preset: preset, Lines: lines
        })).then(function (resp) {
            var text = (resp && resp.Content) ? resp.Content : "";
            lastResult = text; filteredResult = text;
            renderOutput(filteredResult);
            if ($("#splitViewToggle", view).prop("checked")) {
                $("#rawLogContainer", view).addClass("open");
                renderRaw(lastResult);
            } else $("#rawLogContainer", view).removeClass("open");
        }).catch(function (e) { console.error("GetLogContent failed", e); });
    }

    function loadLogs() {
        ApiClient.getJSON(ApiClient.getUrl("AdvancedLogExplorer/GetLogs")).then(function (files) {
            var sel = $("#logFileSelect", view).empty();
            (files || []).forEach(function (f) {
                sel.append($("<option>").attr("value", f).text(f));
            });
            var defaultFile = "embyserver.txt";
            if (files && files.includes(defaultFile)) sel.val(defaultFile);
            else if (files && files.length > 0) sel.val(files[0]);
            var file = sel.val();
            loadPluginFilters(file);
            applyFilter();
        });
    }

    return function (page, params) {
        view = page;
        page.addEventListener("viewshow", function () {
            loadLogs();
            setTimeout(function () { $("#liveSearch", view).focus(); }, 300);
            $(view).on("change", "#logFileSelect", function () {
                loadPluginFilters(this.value); applyFilter();
            });
            $(view).on("change", "#preset,#pluginFilter,#operator,#lineLimit", applyFilter);
            $(view).on("click", "#applyFilter", applyFilter);
            $(view).on("click", "#refreshBtn", applyFilter);
            $(view).on("change", "#splitViewToggle", function () {
                if (this.checked) {
                    $("#rawLogContainer", view).addClass("open");
                    renderRaw(lastResult);
                    if (searchMatches.length > 0) scrollToMatch(currentMatchIndex >= 0 ? currentMatchIndex : 0);
                } else $("#rawLogContainer", view).removeClass("open");
            });
            $(view).on("input", "#liveSearch", function () {
                renderOutput(lastResult);
                if ($("#splitViewToggle", view).prop("checked")) renderRaw(lastResult);
            });
            $(view).on("click", "#nextMatchBtn", function () {
                if (searchMatches.length > 0) scrollToMatch((currentMatchIndex + 1) % searchMatches.length);
            });
            $(view).on("click", "#prevMatchBtn", function () {
                if (searchMatches.length > 0) scrollToMatch((currentMatchIndex - 1 + searchMatches.length) % searchMatches.length);
            });
            $(view).on("click", "#clearSearchBtn", function () {
                $("#liveSearch", view).val(""); $("#searchCount", view).text("");
                searchMatches = []; currentMatchIndex = -1;
                renderOutput(lastResult);
                if ($("#splitViewToggle", view).prop("checked")) renderRaw(lastResult);
                $("#liveSearch", view).focus();
            });
            $(document).on("keydown.ale", function (e) {
                if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "f") {
                    e.preventDefault(); $("#liveSearch", view).focus().select();
                }
            });
        });
        page.addEventListener("viewhide", function () {
            $(document).off("keydown.ale");
        });
    };
});